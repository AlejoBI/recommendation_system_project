package com.apiweb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiwebApplicationTests {

	@Test
	void contextLoads() {
	}

}
